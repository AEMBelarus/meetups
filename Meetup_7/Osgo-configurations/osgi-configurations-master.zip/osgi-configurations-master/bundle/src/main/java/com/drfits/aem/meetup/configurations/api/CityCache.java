package com.drfits.aem.meetup.configurations.api;

/**
 * Created by Evgeniy Fitsner <drfits@drfits.com> on 12/18/16.
 */
public interface CityCache {
}
