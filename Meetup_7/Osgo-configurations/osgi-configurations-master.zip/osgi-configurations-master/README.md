# osgi-configurations
OSGI configuration of components
